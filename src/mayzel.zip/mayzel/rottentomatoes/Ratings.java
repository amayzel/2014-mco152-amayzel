package mayzel.rottentomatoes;

public class Ratings {

	private String critics_rating;

	public Ratings() {

	}

	public String getCritics_rating() {
		return critics_rating;
	}

}
