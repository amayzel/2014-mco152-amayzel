package mayzel.rottentomatoes;

public class Posters {

	private String thumbnail;

	public Posters() {

	}

	public String getThumbnail() {
		return thumbnail;
	}

}
