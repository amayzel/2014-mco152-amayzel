package mayzel.rottentomatoes;

public class RottenTomatoes {

	private Movies[] movies;

	public RottenTomatoes() {

	}

	public Movies[] getMovies() {
		return movies;
	}

}
