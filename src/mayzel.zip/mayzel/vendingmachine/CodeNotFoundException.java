package mayzel.vendingmachine;

public class CodeNotFoundException extends Exception {

	private static final long serialVersionUID = 1L;

}
