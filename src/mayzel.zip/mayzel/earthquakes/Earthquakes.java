package mayzel.earthquakes;

public class Earthquakes {
	private Features[] features;

	public Earthquakes() {

	}

	public Features[] getFeatures() {
		return features;
	}

}
