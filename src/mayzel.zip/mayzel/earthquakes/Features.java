package mayzel.earthquakes;

public class Features {

	private Properties properties;

	public Features() {

	}

	public Properties getProperties() {
		return properties;
	}

}
