package mayzel.earthquakes;

public class Properties {

	private double mag;
	private String place;

	public Properties() {

	}

	public double getMag() {
		return mag;
	}

	public String getPlace() {
		return place;
	}

}
