package mayzel.nytimes;

public class Docs {

	private String lead_paragraph;
	private Headline headline;
	private String web_url;

	public Docs() {

	}

	public String getLead_paragraph() {
		return lead_paragraph;
	}

	public Headline getHeadline() {
		return headline;
	}

	public String getWeb_url() {
		return web_url;
	}

	
}
