package mayzel.nytimes;

public class NYTimes {

	private Response response;

	public NYTimes() {

	}

	public Response getResponse() {
		return response;
	}

}
