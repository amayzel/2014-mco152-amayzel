package mayzel.nytimes;

public class Response {

	private Docs[] docs;

	public Response() {

	}

	public Docs[] getDocs() {
		return docs;
	}
}
