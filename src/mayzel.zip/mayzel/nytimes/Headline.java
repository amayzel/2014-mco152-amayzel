package mayzel.nytimes;

public class Headline {

	private String main;
	private String kicker;

	public Headline() {

	}

	public String getMain() {
		return main;
	}

	public String getKicker() {
		return kicker;
	}

}
