package mayzel.iss;

public class Location {

	private double lng;
	private double lat;

	public Location() {

	}

	public double getLng() {
		return lng;
	}

	public double getLat() {
		return lat;
	}

}
