package mayzel.iss;

public class Geometry {

	public Location location;

	public Geometry() {

	}

	public Location getLocation() {
		return location;
	}

}
