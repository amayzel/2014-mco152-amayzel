package mayzel.iss;

public class ISS {

	private Results[] results;

	public ISS() {

	}

	public Results[] getResults() {
		return results;
	}

}
