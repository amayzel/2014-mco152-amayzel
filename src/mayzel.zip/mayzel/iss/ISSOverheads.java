package mayzel.iss;

public class ISSOverheads {

	private Response[] response;

	public ISSOverheads() {

	}

	public Response[] getResponse() {
		return response;
	}

}
