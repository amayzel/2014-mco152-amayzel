package mayzel.iss;

public class Results {

	private Geometry geometry;

	public Results() {

	}

	public Geometry getGeometry() {
		return geometry;
	}

}
