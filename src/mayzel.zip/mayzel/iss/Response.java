package mayzel.iss;

public class Response {

	private int risetime;

	public Response() {

	}

	public int getRisetime() {
		return risetime;
	}

}
