package mayzel.opportunity;

public class Images {

	private String url;

	public Images() {

	}

	public String getUrl() {
		return url;
	}

}
