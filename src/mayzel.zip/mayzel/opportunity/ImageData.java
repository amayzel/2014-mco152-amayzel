package mayzel.opportunity;

public class ImageData {

	private Images[] images;

	public ImageData() {

	}

	public Images[] getImages() {
		return images;
	}

}
