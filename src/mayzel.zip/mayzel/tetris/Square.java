package mayzel.tetris;

public class Square {

}
