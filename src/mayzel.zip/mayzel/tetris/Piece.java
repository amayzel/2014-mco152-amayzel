package mayzel.tetris;

public class Piece {
	
	protected Square squares[][]; 
	
	public Piece(){
		squares = new Square[4][4];
		
	}
	
	public void rotateRight(){
		//DO THIS FOR HW
	}
	
//	public String toString(){
		
//	}
	
	public void movesRight(){
		
	}
	
	public void movesLeft(){
		
	}
	
	public void movesDown(){
		
	}
	

}
